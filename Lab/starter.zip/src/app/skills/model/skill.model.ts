export interface Skill {
  id: number;
  name: string;
  hours: number;
  completed: boolean;
}
