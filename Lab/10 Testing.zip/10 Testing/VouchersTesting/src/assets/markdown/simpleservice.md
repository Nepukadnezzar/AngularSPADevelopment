Navigate to folder `\demos\simple-service`

Investigate `simple.service.ts` and `simple.service.spec.ts`
