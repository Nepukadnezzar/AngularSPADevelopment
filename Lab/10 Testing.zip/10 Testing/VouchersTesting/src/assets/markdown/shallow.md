Navigate to folder \demos\shallow-integration

Investigate `shallow-integration.component.html`. Notice the `app-food-row` component and instpect it

Take a look at `food-row.component.spec.ts`
