Navigate to folder `\demos\test-pipe`

Investigate `test-pipe.component.ts` and `test-pipe.component.spec.ts`
