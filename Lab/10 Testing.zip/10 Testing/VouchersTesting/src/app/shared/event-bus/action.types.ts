export const cmdToggleDemoMenu = "cmdToggleDemoMenu";
export const cmdToggleAppsMenu = "cmdToggleAppsMenu";
