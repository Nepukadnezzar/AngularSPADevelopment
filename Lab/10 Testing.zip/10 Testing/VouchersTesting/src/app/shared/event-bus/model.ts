
export class CmdItem{
    title: string;
    action: string;
    icon?: string;
}