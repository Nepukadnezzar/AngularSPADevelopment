interface DiagramData {
    name: string;
    value: number;
  }