import { Component, OnInit } from "@angular/core";
import { ChartingService } from "../shared/charting/charting.service";

@Component({
  selector: "app-statistics",
  templateUrl: "./statistics.component.html",
  styleUrls: ["./statistics.component.scss"]
})
export class StatisticsComponent implements OnInit {
  constructor(private rs: ChartingService) {}

  data: DiagramData[];
  view: any[] = [700, 400];

  // options
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = true;
  showXAxisLabel = true;
  xAxisLabel = "Month";
  showYAxisLabel = true;
  yAxisLabel = "Revenue / €";

  colorScheme = {
    domain: ["#5AA454", "#A10A28", "#C7B42C", "#AAAAAA"]
  };

  onSelect(event) {
    console.log(event);
  }

  ngOnInit() {
    this.data = this.rs.getData();
  }
}
