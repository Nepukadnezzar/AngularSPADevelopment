
export class Movie{    
    title: string
    startTime: Date
    img: string
    url: string
}