export class FoodItem {
  name: string;
  rating: number;
}
