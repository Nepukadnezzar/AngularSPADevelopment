export class SimpleClass {
  static sayHelloWorld(): string {
    return "Hello World!";
  }
}
